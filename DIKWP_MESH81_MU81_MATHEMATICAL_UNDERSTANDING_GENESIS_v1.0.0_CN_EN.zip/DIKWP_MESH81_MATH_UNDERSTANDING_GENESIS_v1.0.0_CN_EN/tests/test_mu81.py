from __future__ import annotations
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))

from mu81.model import KINDS, ROUTES, iter_cases, load_case, data_root
from mu81.validator import validate_packet


class MU81Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = list(iter_cases())

    def test_01_five_kinds(self):
        self.assertEqual(KINDS, ('D','I','K','W','P'))

    def test_02_twenty_five_routes(self):
        self.assertEqual(len(ROUTES), 25)
        self.assertEqual(len(set(ROUTES)), 25)

    def test_03_case_count(self):
        self.assertEqual(len(self.cases), 13)

    def test_04_all_cases_valid(self):
        for case in self.cases:
            with self.subTest(case=case['id']):
                result = validate_packet(case)
                self.assertTrue(result['valid'], result['issues'])

    def test_05_all_cases_vector_11111(self):
        for case in self.cases:
            self.assertEqual(validate_packet(case)['understanding_evidence_vector'], '11111')

    def test_06_vector_boundary(self):
        for case in self.cases:
            scope=validate_packet(case)['vector_scope']
            self.assertIn('not theorem truth', scope)

    def test_07_open_bridge_preserved(self):
        for case in self.cases:
            i=[r for r in case['native']['records'] if r['kind']=='I' and r.get('tag')=='external_bridge']
            self.assertEqual(len(i),1)
            self.assertFalse(i[0].get('silenced',False))

    def test_08_definition_load_preserved(self):
        for case in self.cases:
            i=[r for r in case['native']['records'] if r.get('tag')=='definition_load']
            self.assertEqual(len(i),1)
            self.assertTrue(i[0]['payload'])

    def test_09_forward_and_reverse(self):
        for case in self.cases:
            ps=[r for r in case['native']['records'] if r['kind']=='P']
            self.assertTrue(any(p.get('role')=='forward' for p in ps))
            self.assertTrue(any(p.get('role')=='reverse' for p in ps))

    def test_10_w_participates(self):
        for case in self.cases:
            ws={r['id'] for r in case['native']['records'] if r['kind']=='W'}
            forward=[r for r in case['native']['records'] if r.get('role')=='forward']
            self.assertTrue(any(ws.intersection(p['inputs']) for p in forward))

    def test_11_k_covers_open_i(self):
        for case in self.cases:
            iids={r['id'] for r in case['native']['records'] if r['kind']=='I'}
            covers=set().union(*[set(r.get('covers',[])) for r in case['native']['records'] if r['kind']=='K'])
            self.assertTrue(iids.issubset(covers))

    def test_12_friction_types(self):
        required={'HINGE','DEFINITION_LOAD','TRANSLATION'}
        for case in self.cases:
            self.assertTrue(required.issubset({x['kind'] for x in case['friction']}))

    def test_13_three_perturbations(self):
        for case in self.cases:
            self.assertGreaterEqual(len(case['perturbations']),3)

    def test_14_question_deck(self):
        for case in self.cases:
            self.assertGreaterEqual(len(case['questions']),5)

    def test_15_talk_levels(self):
        for case in self.cases:
            self.assertEqual(set(case['talks']), {'3min','20min','expert'})

    def test_16_all_obligations(self):
        expected={f'U{i:02d}' for i in range(1,13)}
        for case in self.cases:
            self.assertEqual(set(case['obligations']), expected)

    def test_17_no_scalar_score(self):
        forbidden={'score','total_score','understanding_score','quality_score','rank'}
        def walk(v):
            if isinstance(v,dict):
                for k,x in v.items():
                    self.assertNotIn(k.lower(), forbidden)
                    walk(x)
            elif isinstance(v,list):
                for x in v: walk(x)
        for case in self.cases: walk(case)

    def test_18_external_claim_has_bridge(self):
        for case in self.cases:
            self.assertTrue(case['alias']['external_claim'])
            self.assertTrue(any(r.get('tag')=='external_bridge' for r in case['native']['records']))

    def test_19_native_append_only(self):
        for case in self.cases:
            self.assertTrue(case['native']['append_only'])
            self.assertFalse(case['native']['final_omniscience'])

    def test_20_route_types_match_endpoints(self):
        for case in self.cases:
            by={r['id']:r['kind'] for r in case['native']['records']}
            for route in case['native']['routes']:
                self.assertEqual(route['kind'], f"{by[route['source']]}>{by[route['target']]}")

    def test_21_repo_inventory(self):
        repos=json.loads((data_root()/'repository_inventory.json').read_text(encoding='utf-8'))
        self.assertGreaterEqual(len(repos),15)
        self.assertEqual(len({r['id'] for r in repos}),len(repos))

    def test_22_triangulation_clusters(self):
        tri=json.loads((data_root()/'triangulations.json').read_text(encoding='utf-8'))
        self.assertEqual({x['id'] for x in tri},{'T_RH','T_BSD','T_HODGE'})

    def test_23_rh_cluster_members(self):
        tri=json.loads((data_root()/'triangulations.json').read_text(encoding='utf-8'))
        rh=next(x for x in tri if x['id']=='T_RH')
        self.assertEqual(set(rh['members']),{'C07_RH_MIRROR','C08_RH_BIPOLAR'})

    def test_24_bsd_cluster_members(self):
        tri=json.loads((data_root()/'triangulations.json').read_text(encoding='utf-8'))
        bsd=next(x for x in tri if x['id']=='T_BSD')
        self.assertEqual(set(bsd['members']),{'C09_BSD_DUAL','C10_BSD_FREEDOM'})

    def test_25_hodge_cluster_members(self):
        tri=json.loads((data_root()/'triangulations.json').read_text(encoding='utf-8'))
        h=next(x for x in tri if x['id']=='T_HODGE')
        self.assertEqual(set(h['members']),{'C11_HODGE_RBACE','C12_HODGE_LIFT'})

    def test_26_ns_bridge_mentions_compactness(self):
        c=load_case('C13_NS_BSTC')
        bridge=next(r['payload'] for r in c['native']['records'] if r.get('tag')=='external_bridge')
        self.assertIn('compactness',bridge)

    def test_27_bsd_bridge_mentions_projection(self):
        c=load_case('C09_BSD_DUAL')
        bridge=next(r['payload'] for r in c['native']['records'] if r.get('tag')=='external_bridge')
        self.assertIn('projections',bridge)

    def test_28_hodge_bridge_mentions_source(self):
        c=load_case('C11_HODGE_RBACE')
        bridge=next(r['payload'] for r in c['native']['records'] if r.get('tag')=='external_bridge')
        self.assertIn('source',bridge)

    def test_29_rh_bridge_mentions_classical(self):
        c=load_case('C07_RH_MIRROR')
        bridge=next(r['payload'] for r in c['native']['records'] if r.get('tag')=='external_bridge')
        self.assertIn('classical',bridge)

    def test_30_bad_aggregate_rejected(self):
        c=json.loads(json.dumps(self.cases[0]))
        c['understanding_score']=99
        self.assertFalse(validate_packet(c)['valid'])

    def test_31_bad_output_injection_rejected(self):
        c=json.loads(json.dumps(self.cases[0]))
        c['native']['routes']=[r for r in c['native']['routes'] if not (r['source']=='P01' and r['target']=='K01')]
        self.assertFalse(validate_packet(c)['valid'])

    def test_32_bad_silenced_i_rejected(self):
        c=json.loads(json.dumps(self.cases[0]))
        next(r for r in c['native']['records'] if r['kind']=='I')['silenced']=True
        self.assertFalse(validate_packet(c)['valid'])

    def test_33_bad_missing_reverse_rejected(self):
        c=json.loads(json.dumps(self.cases[0]))
        c['native']['records']=[r for r in c['native']['records'] if r['id']!='P02']
        c['native']['routes']=[r for r in c['native']['routes'] if r['source']!='P02' and r['target']!='P02']
        self.assertFalse(validate_packet(c)['valid'])

    def test_34_bad_w_decorative_rejected(self):
        c=json.loads(json.dumps(self.cases[0]))
        p=next(r for r in c['native']['records'] if r['id']=='P01')
        p['inputs']=[x for x in p['inputs'] if x!='W01']
        self.assertFalse(validate_packet(c)['valid'])

    def test_35_bad_k_coverage_rejected(self):
        c=json.loads(json.dumps(self.cases[0]))
        k=next(r for r in c['native']['records'] if r['id']=='K01')
        k['covers']=[x for x in k['covers'] if x!='I01']
        self.assertFalse(validate_packet(c)['valid'])

    def test_36_bad_friction_rejected(self):
        c=json.loads(json.dumps(self.cases[0])); c['friction']=[]
        self.assertFalse(validate_packet(c)['valid'])

    def test_37_bad_talk_rejected(self):
        c=json.loads(json.dumps(self.cases[0])); c['talks']={}
        self.assertFalse(validate_packet(c)['valid'])

    def test_38_bad_questions_rejected(self):
        c=json.loads(json.dumps(self.cases[0])); c['questions']=[]
        self.assertFalse(validate_packet(c)['valid'])

    def test_39_bad_perturbation_rejected(self):
        c=json.loads(json.dumps(self.cases[0])); c['perturbations']=[]
        self.assertFalse(validate_packet(c)['valid'])

    def test_40_packet_digest_deterministic(self):
        c=self.cases[0]
        a=validate_packet(c)['packet_digest']
        b=validate_packet(json.loads(json.dumps(c)))['packet_digest']
        self.assertEqual(a,b)


if __name__ == '__main__':
    unittest.main()
