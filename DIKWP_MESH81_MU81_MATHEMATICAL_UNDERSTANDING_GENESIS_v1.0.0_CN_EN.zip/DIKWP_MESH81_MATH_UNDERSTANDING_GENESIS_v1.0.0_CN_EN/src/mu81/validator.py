from __future__ import annotations

from typing import Any
from .model import KINDS, ROUTES, ValidationIssue, digest

FORBIDDEN_AGGREGATES = {"score", "total_score", "understanding_score", "quality_score", "rank"}


def _issue(issues: list[ValidationIssue], level: str, code: str, message: str, record_id: str | None = None) -> None:
    issues.append(ValidationIssue(level, code, message, record_id))


def _walk_keys(value: Any):
    if isinstance(value, dict):
        for key, child in value.items():
            yield str(key)
            yield from _walk_keys(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk_keys(child)


def validate_packet(packet: dict[str, Any]) -> dict[str, Any]:
    issues: list[ValidationIssue] = []
    if packet.get("format") != "MU81-1":
        _issue(issues, "ERROR", "FORMAT", "format must be MU81-1")

    for key in _walk_keys(packet):
        if key.lower() in FORBIDDEN_AGGREGATES:
            _issue(issues, "ERROR", "GOODHART_AGGREGATE", f"forbidden aggregate metric key: {key}")

    native = packet.get("native")
    if not isinstance(native, dict):
        _issue(issues, "ERROR", "NATIVE_MISSING", "native core is missing")
        native = {}

    records = native.get("records", [])
    routes = native.get("routes", [])
    if not isinstance(records, list) or not records:
        _issue(issues, "ERROR", "RECORDS", "native.records must be a non-empty list")
        records = []
    if not isinstance(routes, list):
        _issue(issues, "ERROR", "ROUTES", "native.routes must be a list")
        routes = []

    by_id: dict[str, dict[str, Any]] = {}
    for rec in records:
        rid = rec.get("id")
        kind = rec.get("kind")
        if not isinstance(rid, str) or not rid:
            _issue(issues, "ERROR", "RECORD_ID", "record id is required")
            continue
        if rid in by_id:
            _issue(issues, "ERROR", "DUPLICATE_ID", f"duplicate record id {rid}", rid)
            continue
        by_id[rid] = rec
        if kind not in KINDS:
            _issue(issues, "ERROR", "CORE_KIND", f"record kind must be one of {KINDS}", rid)
        if "payload" not in rec:
            _issue(issues, "ERROR", "PAYLOAD", "record payload is required", rid)

    route_pairs: set[tuple[str, str]] = set()
    used_route_kinds: set[str] = set()
    for route in routes:
        src = route.get("source")
        dst = route.get("target")
        kind = route.get("kind")
        if src not in by_id or dst not in by_id:
            _issue(issues, "ERROR", "ROUTE_REF", f"route endpoint missing: {src}->{dst}")
            continue
        expected = f"{by_id[src].get('kind')}>{by_id[dst].get('kind')}"
        if kind != expected or kind not in ROUTES:
            _issue(issues, "ERROR", "ROUTE_KIND", f"route {src}->{dst} must be {expected}, not {kind}")
        route_pairs.add((src, dst))
        used_route_kinds.add(expected)

    forward_ps: list[dict[str, Any]] = []
    reverse_ps: list[dict[str, Any]] = []
    for rec in records:
        if rec.get("kind") != "P":
            continue
        inputs = rec.get("inputs", [])
        outputs = rec.get("outputs", [])
        if not isinstance(inputs, list) or not isinstance(outputs, list) or not outputs:
            _issue(issues, "ERROR", "P_IO", "P requires inputs and at least one output", rec.get("id"))
            continue
        for ref in inputs + outputs:
            if ref not in by_id:
                _issue(issues, "ERROR", "P_REF", f"P references missing record {ref}", rec.get("id"))
        for out in outputs:
            if out in by_id and (rec.get("id"), out) not in route_pairs:
                _issue(issues, "ERROR", "OUTPUT_INJECTION", f"P output {out} lacks an explicit route", rec.get("id"))
        role = rec.get("role")
        if role == "forward":
            forward_ps.append(rec)
        elif role == "reverse":
            reverse_ps.append(rec)

    if not forward_ps:
        _issue(issues, "ERROR", "FORWARD_P", "at least one forward P is required")
    if not reverse_ps:
        _issue(issues, "ERROR", "REVERSE_P", "at least one reverse-regeneration P is required")

    given = [r for r in records if r.get("given", True)]
    given_ids = {r.get("id") for r in given}
    k_records = [r for r in records if r.get("kind") == "K"]
    covered_ids: set[str] = set()
    for k in k_records:
        covered_ids.update(k.get("covers", []))
        for ref in k.get("covers", []):
            if ref not in by_id:
                _issue(issues, "ERROR", "K_REF", f"K covers missing record {ref}", k.get("id"))
    required_for_k = {r.get("id") for r in given if r.get("kind") in {"D", "I", "W"}}
    required_for_k.update(p.get("id") for p in forward_ps)
    missing_k = sorted(x for x in required_for_k if x not in covered_ids)
    if missing_k:
        _issue(issues, "ERROR", "K_COVERAGE", f"K does not cover: {', '.join(missing_k)}")

    w_ids = {r.get("id") for r in records if r.get("kind") == "W" and r.get("given", True)}
    w_participates = any(w_ids.intersection(set(p.get("inputs", []))) for p in forward_ps)
    if w_ids and not w_participates:
        _issue(issues, "ERROR", "W_DECORATIVE", "W exists but does not participate in a forward P")

    i_records = [r for r in records if r.get("kind") == "I"]
    if not i_records:
        _issue(issues, "ERROR", "I_MISSING", "at least one I record is required to preserve difference/open limits")
    for rec in i_records:
        if rec.get("silenced") is True:
            _issue(issues, "ERROR", "I_SILENCED", "I may not be silently eliminated", rec.get("id"))

    alias = packet.get("alias", {})
    if alias.get("external_claim") and not any(r.get("tag") == "external_bridge" for r in i_records):
        _issue(issues, "ERROR", "BRIDGE_HIDDEN", "an external claim requires an explicit external_bridge I record")
    if alias.get("novelty_claim") and not packet.get("friction"):
        _issue(issues, "ERROR", "FRICTION_MISSING", "a novelty claim requires a friction map")
    if not packet.get("talks"):
        _issue(issues, "ERROR", "TALK_MISSING", "talk regeneration package is required")
    if not packet.get("questions"):
        _issue(issues, "ERROR", "QUESTIONS_MISSING", "expert question deck is required")
    if not packet.get("perturbations"):
        _issue(issues, "ERROR", "PERTURBATION_MISSING", "at least one perturbation test is required")

    # Evidence vector: structural evidence of understanding only, never theorem truth.
    d_closed = bool(any(r.get("kind") == "D" for r in records)) and any(
        any(by_id.get(out, {}).get("kind") == "D" for out in p.get("outputs", [])) for p in reverse_ps
    )
    i_closed = bool(i_records) and all(r.get("id") in covered_ids for r in i_records)
    k_closed = bool(k_records) and not missing_k
    w_closed = (not w_ids) or w_participates
    p_closed = bool(forward_ps and reverse_ps) and all(
        any(by_id.get(inp, {}).get("kind") == "K" for inp in p.get("inputs", [])) for p in reverse_ps
    )
    vector = "".join("1" if x else "0" for x in (d_closed, i_closed, k_closed, w_closed, p_closed))

    errors = [i for i in issues if i.level == "ERROR"]
    warnings = [i for i in issues if i.level == "WARNING"]
    result = {
        "packet_id": packet.get("id"),
        "valid": not errors,
        "understanding_evidence_vector": vector,
        "vector_order": "DIKWP",
        "vector_scope": "declared understanding evidence only; not theorem truth",
        "core_digest": digest(native),
        "packet_digest": digest(packet),
        "record_count": len(records),
        "route_count": len(routes),
        "route_kinds_used": sorted(used_route_kinds),
        "issues": [i.as_dict() for i in issues],
        "error_count": len(errors),
        "warning_count": len(warnings),
    }
    return result
