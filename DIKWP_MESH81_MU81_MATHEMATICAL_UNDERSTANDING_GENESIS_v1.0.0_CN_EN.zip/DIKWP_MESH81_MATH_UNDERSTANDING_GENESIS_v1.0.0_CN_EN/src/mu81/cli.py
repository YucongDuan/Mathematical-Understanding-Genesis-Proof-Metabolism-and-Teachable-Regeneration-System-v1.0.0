from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from .model import ROUTES, data_root, iter_cases, load_case, load_json
from .validator import validate_packet


def _dump(value):
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def cmd_summary(_args):
    cases = list(iter_cases())
    repos = load_json(data_root() / "repository_inventory.json")
    tri = load_json(data_root() / "triangulations.json")
    vectors = {}
    for case in cases:
        v = validate_packet(case)["understanding_evidence_vector"]
        vectors[v] = vectors.get(v, 0) + 1
    _dump({
        "system": "DIKWP-MESH8.1 MU81",
        "version": "1.0.0",
        "case_packets": len(cases),
        "repository_entries": len(repos),
        "triangulation_clusters": len(tri),
        "route_types": len(ROUTES),
        "evidence_vectors": vectors,
        "important_boundary": "evidence vector measures declared regenerative-understanding structure, not mathematical truth",
    })


def cmd_list(args):
    rows = []
    for case in iter_cases():
        if args.family and case.get("alias", {}).get("family") != args.family:
            continue
        rows.append({
            "id": case["id"],
            "title": case.get("alias", {}).get("title_cn"),
            "family": case.get("alias", {}).get("family"),
            "bridge_state": case.get("alias", {}).get("external_bridge_state"),
            "vector": validate_packet(case)["understanding_evidence_vector"],
        })
    _dump(rows)


def cmd_show(args):
    case = load_case(args.case_id)
    if args.native:
        _dump(case["native"])
    else:
        _dump(case)


def cmd_validate(args):
    packet = load_json(args.file)
    result = validate_packet(packet)
    _dump(result)
    return 0 if result["valid"] else 2


def cmd_routes(_args):
    for i, route in enumerate(ROUTES, 1):
        print(f"{i:02d} {route}")


def cmd_talk(args):
    case = load_case(args.case_id)
    talks = case.get("talks", {})
    value = talks.get(args.level)
    if value is None:
        raise SystemExit(f"talk level not found: {args.level}")
    if isinstance(value, list):
        for i, item in enumerate(value, 1):
            print(f"{i}. {item}")
    else:
        print(value)


def cmd_questions(args):
    case = load_case(args.case_id)
    for i, q in enumerate(case.get("questions", []), 1):
        print(f"Q{i}: {q['question']}")
        print(f"  expected evidence: {', '.join(q.get('expected_evidence', []))}")


def cmd_triangulate(args):
    clusters = load_json(data_root() / "triangulations.json")
    selected = [x for x in clusters if x["id"] == args.cluster_id]
    if not selected:
        raise SystemExit(f"unknown cluster: {args.cluster_id}")
    _dump(selected[0])


def cmd_selftest(_args):
    failures = []
    count = 0
    for case in iter_cases():
        count += 1
        result = validate_packet(case)
        if not result["valid"]:
            failures.append({"id": case["id"], "issues": result["issues"]})
    out = {"cases_checked": count, "failures": failures, "pass": not failures}
    _dump(out)
    return 0 if not failures else 2


def build_parser():
    p = argparse.ArgumentParser(prog="mu81", description="Mathematical Understanding Genesis and Proof Metabolism")
    sub = p.add_subparsers(dest="command", required=True)
    s = sub.add_parser("summary"); s.set_defaults(func=cmd_summary)
    s = sub.add_parser("list"); s.add_argument("--family"); s.set_defaults(func=cmd_list)
    s = sub.add_parser("show"); s.add_argument("case_id"); s.add_argument("--native", action="store_true"); s.set_defaults(func=cmd_show)
    s = sub.add_parser("validate"); s.add_argument("file", type=Path); s.set_defaults(func=cmd_validate)
    s = sub.add_parser("routes"); s.set_defaults(func=cmd_routes)
    s = sub.add_parser("talk"); s.add_argument("case_id"); s.add_argument("--level", choices=["3min", "20min", "expert"], default="3min"); s.set_defaults(func=cmd_talk)
    s = sub.add_parser("questions"); s.add_argument("case_id"); s.set_defaults(func=cmd_questions)
    s = sub.add_parser("triangulate"); s.add_argument("cluster_id"); s.set_defaults(func=cmd_triangulate)
    s = sub.add_parser("selftest"); s.set_defaults(func=cmd_selftest)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    rc = args.func(args)
    return 0 if rc is None else rc

if __name__ == "__main__":
    sys.exit(main())
