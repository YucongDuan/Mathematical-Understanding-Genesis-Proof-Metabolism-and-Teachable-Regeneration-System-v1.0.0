from __future__ import annotations

from dataclasses import dataclass
from importlib.resources import files
from typing import Any, Iterable
import hashlib
import json

KINDS = ("D", "I", "K", "W", "P")
ROUTES = tuple(f"{a}>{b}" for a in KINDS for b in KINDS)


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def data_root():
    """Return the package data root as an importlib Traversable.

    This works from source trees, installed wheels, and zipapps without
    extracting package data to an implicit working directory.
    """
    return files("mu81").joinpath("data")


def load_json(path: Any) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_case(case_id: str) -> dict[str, Any]:
    path = data_root().joinpath("cases", f"{case_id}.json")
    if not path.is_file():
        raise FileNotFoundError(f"unknown case: {case_id}")
    return load_json(path)


def iter_cases() -> Iterable[dict[str, Any]]:
    case_dir = data_root().joinpath("cases")
    paths = sorted(
        (item for item in case_dir.iterdir() if item.name.endswith(".json")),
        key=lambda item: item.name,
    )
    for path in paths:
        yield load_json(path)


@dataclass(frozen=True)
class ValidationIssue:
    level: str
    code: str
    message: str
    record_id: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "level": self.level,
            "code": self.code,
            "message": self.message,
            "record_id": self.record_id,
        }
