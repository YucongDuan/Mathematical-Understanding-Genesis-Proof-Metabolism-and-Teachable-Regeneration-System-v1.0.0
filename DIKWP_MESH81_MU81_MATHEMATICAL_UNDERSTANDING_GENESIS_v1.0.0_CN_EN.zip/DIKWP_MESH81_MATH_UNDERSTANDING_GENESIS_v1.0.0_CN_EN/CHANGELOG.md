# Changelog

## 1.0.0 — 2026-08-10

- Introduced the MU81 D/I/K/W/P-native understanding-evidence protocol.
- Added 12 understanding obligations, 25 route aliases, 13 audited proof/system packets, and three cross-proof triangulation clusters.
- Added definition-load, decisive-seam, natural-friction, perturbation, migration, talk, and expert-question layers.
- Added offline dashboard, JSON schema, Python CLI, wheel, zipapp, tests, and formal Chinese report.
- Preserved the boundary between understanding evidence, kernel acceptance, and external theorem truth.
