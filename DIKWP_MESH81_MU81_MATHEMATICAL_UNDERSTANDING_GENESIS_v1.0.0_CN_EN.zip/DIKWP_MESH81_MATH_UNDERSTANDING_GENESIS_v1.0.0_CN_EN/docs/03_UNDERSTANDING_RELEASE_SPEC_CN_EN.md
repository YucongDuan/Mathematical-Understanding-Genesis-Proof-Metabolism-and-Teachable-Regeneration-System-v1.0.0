# Understanding Release / 理解发布包规范

每个发布包至少包含：

- 原始来源、版本和工具披露；
- 主张层级与外部状态边界；
- D/I/K/W/P 原生记录及路径；
- 定义负载审计；
- 决定性接缝与开放关系；
- 自然摩擦图；
- 多分辨率说明；
- 反向再生任务；
- 扰动与迁移试验；
- 三分钟、二十分钟和专家级报告；
- 专家问答卡；
- 归因与先验知识图；
- 教材化或复用输出；
- 明确的“已知不理解”登记。

No scalar score is permitted to substitute for these evidence records.
