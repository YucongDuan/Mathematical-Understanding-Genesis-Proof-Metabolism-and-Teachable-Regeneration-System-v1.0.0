# 从证明生命周期到证明代谢

Tao 的六阶段管道是：生成、核验、阐述、发表、消化、经典化。MU81 不否定这条现实流程，而是补充一个跨越各阶段的再生环：来源锁定、定义负载、决定性接缝、摩擦保存、反向再生、扰动、迁移、讲授、问答、经典化与真实复用。

The six-stage lifecycle is supplemented by a regenerative loop. The loop does not optimize a single digestibility metric. It stores non-aggregated evidence and preserves open differences.
