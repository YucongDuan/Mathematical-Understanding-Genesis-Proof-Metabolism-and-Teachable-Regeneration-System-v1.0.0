# MU81 v1.0.0 Release Notes / 发布说明

MU81 converts proof artifacts into auditable understanding-release packets. It preserves provenance, irreducible differences, definition load, decisive seams, natural friction, reverse regeneration, perturbation, migration, talks, questions, attribution, and canonicalization evidence.

MU81 将证明文件重构为可审计的理解发布包，显式保存来源、不可合并差异、定义负载、决定性接缝、自然摩擦、反向再生、扰动、迁移、报告、问答、归因与经典化证据。

The release contains 13 case packets, 25 route types, 12 understanding obligations, 3 cross-proof triangulation clusters, an offline dashboard, a Python CLI, a wheel, a zipapp, a JSON schema, 40 tests, and a 38-page Chinese formal report.

Boundary: `11111` is not theorem truth and not automatic evidence that a living person has passed a real expert talk. It means that the declared understanding-evidence structure covers D/I/K/W/P under the MU81 protocol.
